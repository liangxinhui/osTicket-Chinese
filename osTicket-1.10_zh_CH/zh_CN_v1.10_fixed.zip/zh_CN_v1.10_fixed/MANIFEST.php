<?php return array (
  'Build-Date' => 'Fri, 13 Jan 17 17:14:06 +0000',
  'Phrases-Version' => '1.10',
  'Build-Version' => 'v1.10-6-gc0ab967',
  'Build-Major-Version' => '1.10',
  'Language' => 'zh_CN',
  'Id' => 'lang:zh_CN',
  'Last-Revision' => '2016-12-27 16:55-0500',
  'Version' => 148287,
);